<?php

session_start();
if(!isset($_SESSION['email'])){
header("location:login.php");
exit;
}


$hostname="localhost";
$username="root";
$password="root";
$database="bloodbank";
$con=mysqli_connect($hostname,$username,$password,$database);

?>

<!doctype html>
<html>
	<head>
		<title>Bar Chart</title>
		<script src="js/Chart.min.js"></script>
	</head>
	<body>
		<div style="width: 50%">
			<canvas id="canvas" height="450" width="600"></canvas>
			
		</div>
		<u>Legend:</u>
		<div id="legend"></div>
	<script>
	var randomScalingFactor = function(){ return Math.round(Math.random()*100)};

	var barChartData = {
		labels : [
		<?php 
			$query="select distinct blood_group from donor order by blood_group asc";
			$result=mysqli_query($con,$query);
			$bgroups=array();
			while($row=mysqli_fetch_assoc($result)){
				echo   '"',$row['blood_group'].'", ';
				array_push($bgroups,$row['blood_group']);
			}
		?>
		],
		datasets : [ 
			{
				label: "Male",
				fillColor : "rgba(220,220,220,0.5)",
				strokeColor : "rgba(220,220,220,0.8)",
				highlightFill: "rgba(220,220,220,0.75)",
				highlightStroke: "rgba(220,220,220,1)",
				data : [//male
				<?php 
					foreach($bgroups as $bg){
						$query="select * from donor where blood_group='$bg' and gender='m'";
						$result=mysqli_query($con,$query);
						if($result)
							echo $result->num_rows.',';
						else
							echo "0,"; //just in case
					}
				
				?>
				]
			},
			{
				label: "Female",
				fillColor : "rgba(151,187,205,0.5)",
				strokeColor : "rgba(151,187,205,0.8)",
				highlightFill : "rgba(151,187,205,0.75)",
				highlightStroke : "rgba(151,187,205,1)",
				data : [//female
				<?php 
					foreach($bgroups as $bg){
						$query="select * from donor where blood_group='$bg' and gender='f'";
						$result=mysqli_query($con,$query);
						if($result)
							echo $result->num_rows.',';
						else
							echo "0,"; //just in case
					}
				
				?>
				]
			}
		],
		legendTemplate : "<ul class=\"<%=name.toLowerCase()%>-legend\"><% for (var i=0; i<datasets.length; i++){%><li><span style=\"background-color:<%=datasets[i].fillColor%>\"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>"

	}
	window.onload = function(){
		var ctx = document.getElementById("canvas").getContext("2d");
		window.myBar = new Chart(ctx).Bar(barChartData, {
			responsive : true
		});
		
		document.getElementById("legend").innerHTML=window.myBar.generateLegend();
	}

	</script>
	</body>
</html>