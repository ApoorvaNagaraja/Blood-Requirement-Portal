<?php
session_start();
if(!isset($_SESSION['email'])){
header("location:login.php");
exit;}
?>
<!--!DOCTYPE html-->
<html lang="en">
<head>
	<link id="page_favicon" href="images/favicon.ico" rel="icon" type="image/x-icon">
	<title>Blood Bank Management</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="css/style2.css">
	<link rel="stylesheet" href="css/my_reset.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/my_style.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/my_grid.css" type="text/css" media="screen">
	<script src="js/jquery-1.6.3.min.js" type="text/javascript"></script>
	<script src="js/tabs.js" type="text/javascript"></script>
	</head>
<body id="page1">
<div class="bg">

  <!--==============================header=================================-->
  <header>
   
  <div class="main">
      <div class="wrapper p3">
        <h1><a href="login.php">Blood Bank</a></h1>
        <form id="search-form" action="#" method="post" enctype="multipart/form-data">
          <fieldset>
            
          </fieldset>
        </form>
      </div>
    </div>
</header>
<br><br><br><br>

<form action="upload-backend.php" method="post"  enctype="multipart/form-data">  <label > Click Here</label> <input type="file" name="file" id="file"
				onchange="document.forms[0].submit()"> 
				</form> 
<br>
							<form action="s_index.php" method="post">
   						 <button type="submit" class="btn btn-lg btn-danger">BACK</button>	 
                         	</form>
   						 
				</body>
				</html>