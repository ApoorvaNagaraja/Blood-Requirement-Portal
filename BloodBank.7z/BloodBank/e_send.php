<?php
session_start();
?>
<!--!DOCTYPE html-->
<html lang="en">
<head>
	<link id="page_favicon" href="images/favicon.ico" rel="icon" type="image/x-icon">
	<title>Blood Bank Management</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="css/my_reset.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/my_style.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/my_grid.css" type="text/css" media="screen">
	<script src="js/jquery-1.6.3.min.js" type="text/javascript"></script>
	<script src="js/tabs.js" type="text/javascript"></script>
	<?php
	//echo "a=5;";
	//var_dump($_POST);
	//echo "*/";
if(isset($_POST['name'])){
	//echo "gotcha=5;\n";
$hostname="localhost"; 
$username="root"; 
$password="root"; 
$database="bloodbank";
  
$con=mysqli_connect($hostname,$username,$password,$database);
if(!$con)
{
        die('Connection Failed'.mysqli_error());
}
$msg= "{$_POST['name']} needs blood {$_POST['bloodgroup']} at hospital-{$_POST['hospital']}({$_POST['area']}) \\nContact: {$_POST['phno']} / {$_POST['email']}";

//echo ($msg);

$sql="SELECT ph_number, email_id from donor where blood_group='{$_POST['bloodgroup']}' and area='{$_POST['area']}' ";


$res=mysqli_query($con,$sql);
$num_rows = mysqli_num_rows($res);
//echo $num_rows;
$phnos="";
$emails="";
while($row=mysqli_fetch_assoc($res)) { 
	$phnos.=$row['ph_number'].' ';
	$emails.=$row['email_id'].' ';
	}
	/*
	echo http_get ("hell/sms.php", array("special" => "selene", 'sub' =>'way2sms', 'm'=> $msg , 'c[]' => $phnos))."<hr>";
	echo http_get ("mailer/examples/yahoo.php", array( 'm'=> $msg , 'to' => $emails));
	*/
	
	?>
	
	<script type="text/javascript">	
	
	$( //dcument.ready
	function (){
		msg = '<?php echo $msg; ?>';
		msg1= '<?php echo $msg; echo "no of donors = "; echo $num_rows; ?>';
		alert(msg1);
		
	/*	msg2= '<?php echo $num_rows; ?>';
		alert("The number of donors available are "msg2); */

	$.get( "http://shu.16mb.com/hell/sms.php", 	{'c[]': '<?php echo $phnos ; ?>' , special: 'selene', sub:'way2sms', m:msg, 
		//u:'ppg9DzcJcgO6LxildJ1wwbSnJJ0cZIWFG+4WoLv0J0w=', q: 'AIxoia8bLOjH3MZTXF79b4+NaXkpJ+zXz5CjnobRXDg='
		u:'r2WGChBGQ7uj5jnKt91JVnx5pSsSx/SnlcqykrFsDWk=', q:'fzYEdul0pFZthy2HicmgkOhIkwU74UpDxUUqbC1jaIE='
	});//.done(finish);
	$.get("mailer/examples/yahoo.php",	{m:msg , to: '<?php echo $emails ; ?>'	}).done(finish);
	}	
);
	function finish(data){
		if(data.indexOf('failed')==-1)
			$('h3').html("Sent");
		else
			$('h3').html(data);
		a=data;
		console.log(data);
	}

</script>
<?php } ?>	

</head>
	
<body id="page2">
<div class="bg">
  <!--==============================header=================================-->
  <header>
    <div class="menu-row">
      <div class="main">
        <nav>
           <ul class="menu wrapper">
            <li><a href="e_index.php">Home Page</a></li>
            <li><a href="query2.php">Ask For Blood</a></li>
            				<li><a href="logout.php">Log out</a></li>

            <li><a class="active" href="contacts2.php">Contact Us</a></li>
          </ul>
        </nav>
      </div>
    </div>
	<div class="main">
      <div class="wrapper p3">
        <h1><a href="e_index.php">Blood Bank</a></h1>
        <form id="search-form" action="#" method="post" enctype="multipart/form-data">
          <fieldset>
            
          </fieldset>
        </form>
      </div>
    </div>
    <div class="row-bot"></div>
  </header>
  <!--==============================content================================-->
  <section id="content">
    <div class="main">
      <div class="container_12">
        <div class="wrapper">
          <article class="grid_8">
            <h3>Sending....</h3>
            
          </article>
        </div>
      </div>
    </div>
  </section>
</div>
  <!--==============================footer=================================--><footer>
  <div class="main">
    <div class="aligncenter"> <span>Copyright &copy; Developed by Aparna Joshi and Apoorva N</div>
  </div>
</footer>

  </body>
</html>