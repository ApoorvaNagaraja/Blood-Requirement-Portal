<?php
session_start();

?>
<!--!DOCTYPE html-->
<html lang="en">
<head>
	<link id="page_favicon" href="images/favicon.ico" rel="icon" type="image/x-icon">
	<title>Blood Bank Management</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="css/my_reset.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/my_style.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/my_grid.css" type="text/css" media="screen">
	<script src="js/jquery-1.6.3.min.js" type="text/javascript"></script>
	<script src="js/tabs.js" type="text/javascript"></script>
	<?php
	
if(isset($_POST['name'])){
	//echo "gotcha=5;\n";
$hostname="localhost"; 
$username="root"; 
$password="root"; 
$database="bloodbank";
  
$con=mysqli_connect($hostname,$username,$password,$database);
if(!$con)
{
        die('Connection Failed'.mysqli_error());
}
$msg= "Feed Back by : {$_POST['name']} Email id : {$_POST['email']} Feed back - {$_POST['area']} ";

	?>
	
	<script type="text/javascript">	
	
	$( 
	function (){
		msg = '<?php echo $msg; ?>';

		alert(msg);   
$.get("mailer/examples/yahoo1.php",	{m:msg })
.done(finish);
	}		
                                             	

);

	function finish(data){
		if(data.indexOf('failed')==-1)
			$('h3').html("Sent");
		else
			$('h3').html(data);
		a=data;
		console.log(data);
	}

	
	

</script>
<?php } ?>	

</head>
	
<body id="page2">
<div class="bg">
  <!--==============================header=================================-->
  <header>
    <div class="menu-row">
      <div class="main">
        <nav>
           <ul class="menu wrapper">
           <li><a href="e_index.php">Home Page</a></li>
            <li><a href="query2.php">Ask For Blood</a></li>
            				<li><a href="logout.php">Log out</a></li>

            <li><a class="active" href="contacts2.php">Contact Us</a></li>
          </ul>
        </nav>
      </div>
    </div>
	<div class="main">
      <div class="wrapper p3">
        <h1><a href="e_index.php">Blood Bank</a></h1>
        <form id="search-form" action="#" method="post" enctype="multipart/form-data">
          <fieldset>
            
          </fieldset>
        </form>
      </div>
    </div>
    <div class="row-bot"></div>
  </header>
  <!--==============================content================================-->
  <section id="content">
    <div class="main">
      <div class="container_12">
        <div class="wrapper">
          <article class="grid_8">
            <h3>Sending....</h3>
            
          </article>
        </div>
      </div>
    </div>
  </section>
</div>
 
  <!--==============================footer=================================--><footer>
  <div class="main">
    <div class="aligncenter"> <span>Copyright &copy; Developed by Aparna Joshi and Apoorva N</div>
  </div>
</footer>

  </body>
</html>