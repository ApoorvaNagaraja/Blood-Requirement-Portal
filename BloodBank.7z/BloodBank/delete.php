<?php
session_start();
if(!isset($_SESSION['email'])){
header("location:login.php");
exit;
} ?>
<!--!DOCTYPE html-->
<html lang="en">
<head>
	<link id="page_favicon" href="images/favicon.ico" rel="icon" type="image/x-icon">
	<title>Blood Bank Management</title>
	<meta charset="utf-8">
	 <link rel="stylesheet" href="css/style2.css">
	<link rel="stylesheet" href="css/my_reset.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/my_style.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/my_grid.css" type="text/css" media="screen">
	<script src="js/jquery-1.6.3.min.js" type="text/javascript"></script>
	<script src="js/tabs.js" type="text/javascript"></script>
	</head>
<body id="page1">
<div class="bg">
<header>
    
	<div class="main">
      <div class="wrapper p3">
        <h1><a href="login.php">Blood Bank</a></h1>
        
      </div>
    </div>
	</header>
<?php						 
	 
$hostname="localhost";
$username="root";
$password="root";
$database="bloodbank";
                	$con=mysqli_connect($hostname,$username,$password,$database);
                	if(isset($_POST['donorid']))
                	{
                    	$id=$_POST['donorid'];
                    	$query1="DELETE from donor where d_id='$id';";
						$query2="DELETE from address where d_id='$id';";
						$query3="DELETE from donor_details where d_id='$id';";
						$query4="DELETE from blood where d_id='$id';";
                    	$result1=mysqli_query($con,$query1);
						$result2=mysqli_query($con,$query2);
						$result3=mysqli_query($con,$query3);
						$result4=mysqli_query($con,$query4);
                     	if($result1){
   						 ?>
						 
	
	
						 
     <div class="alert alert-success">
    	<a href="#" class="close" data-dismiss="alert">&times;</a>
    	<strong>Entry deleted</strong> successfully!
	</div>
    <?php
   					 }
                	}
            	?>
 
 
 <form action = "" method = "post">
                                	<div class="form-group">
                                	<div class="input-group">
                                     	<select class = "form-control" name="donorid" >
                                        	<option value=0 selected disabled required>Choose a donor </option>
                                        	<?php
                                                	$con=mysqli_connect($hostname,$username,$password,$database);
                                                	$query="SELECT d_id,name from donor";
                                                	$result=mysqli_query($con,$query);
                                                	while($row=mysqli_fetch_assoc($result))
                                                	{
                                                 	echo "<option value=".$row['d_id'].">".$row['d_id']." ".$row['name']."</option>";
                                                	}
                                                	mysqli_close();
                                        	?>
                                    	</select>
                                	</div>
                            	</div>
                            	<button type="submit" class="btn btn-lg btn-danger">Remove</button>	 
                         	</form>
							<br>
							<form action="index.php" method="post">
   						 <button type="submit" class="btn btn-lg btn-danger">BACK</button>	 
                         	</form>
   						 
   						  </body>
</html>

