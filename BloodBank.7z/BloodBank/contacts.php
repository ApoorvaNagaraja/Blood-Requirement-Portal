<?php
session_start();
if(!isset($_SESSION['email'])){
header("location:login.php");
exit;}
?>
<!--!DOCTYPE html-->
<html lang="en">
<head>
	<link id="page_favicon" href="images/favicon.ico" rel="icon" type="image/x-icon">
	<title>Blood Bank Management</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="css/style2.css">
	<link rel="stylesheet" href="css/my_reset.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/my_style.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/my_grid.css" type="text/css" media="screen">
	<script src="js/jquery-1.6.3.min.js" type="text/javascript"></script>
	<script src="js/tabs.js" type="text/javascript"></script>
	<script src="http://maps.googleapis.com/maps/api/js"></script>
	<script>
	function initialize() {
	var mapProp = {
    center:new google.maps.LatLng(12.9239,77.4997),
    zoom:15,
    mapTypeId:google.maps.MapTypeId.ROADMAP
	};
	var map=new google.maps.Map(document.getElementById("googleMap"),mapProp);
	}
	google.maps.event.addDomListener(window, 'load', initialize);
	</script>
	
	<!--<script type="text/javascript">
	
	function teleport(){

		var1=$('#name').val();
		var2=$('#email').val();
		var3=$('#area').val();
		
		msg= "The Feed Back is gvien by : "+var1+"\nEmail : "+var2+"\nMessage : "+var3;
alert(msg);
	$.get("mailer/examples/yahoo1.php",
		{m:msg 	}
		)
		.done(finish);

		return false;
		}
	
<?php
/*
$hostname="localhost"; 
$username="root"; 
$password="root"; 
$database="bloodbank";
  
$con=mysqli_connect($hostname,$username,$password,$database);
if(!$con)
{
        die('Connection Failed'.mysqli_error());
}

$sql="SELECT ph_number, email_id from donor where blood_group='O+' and area='Bangalore North' ";
$res=mysqli_query($con,$sql);
$phnos="";
$emails="";
while($row=mysqli_fetch_assoc($res)) { 
	$phnos.=$row['ph_number'].' ';
	$emails.=$row['email_id'].' ';
	}
                                            	    
		?>
			
		$.get("mailer/examples/yahoo1.php",
		{m:msg 	}
		)
		.done(finish);

		return false;
	}
                                                 	
  */                                              	

?>
		

	function finish(data){
		console.log(data);
		alert('check console log');
		

	}
	</script> -->
</head>
<body id="page5">
<div class="bg">
  <!--==============================header=================================-->
  <header>
    <div class="menu-row">
      <div class="main">
        <nav>
          <ul class="menu wrapper">
            <li><a href="index.php">Home Page</a></li>
            <li><a href="query.php">Ask For Blood</a></li>
            <li><a href="statistics.php">Statistics</a></li>
			<?php 
			if(isset($_SESSION['email'])){ //logged in ?>
				<li><a href="logout.php">Log out</a></li>
			<?php }else { ?>
				<li><a href="login.php">Log in</a></li>
			<?php } ?>	
            <li><a class="active" href="contacts.php">Contact Us</a></li>
          </ul>
        </nav>
      </div>
    </div>
	<div class="main">
      <div class="wrapper p3">
        <h1><a href="index.php">Blood Bank</a></h1>
        <form id="search-form" action="#" method="post" enctype="multipart/form-data">
          <fieldset>
           
          </fieldset>
        </form>
      </div>
    </div>
    <div class="row-bot"></div>
  </header>
  <!--==============================content================================-->
  <section id="content">
    <div class="main">
      <div class="container_12">
        <div class="wrapper">
          <article class="grid_8">
            <h3>Contact Form</h3>
            <form id="contact-form" action="send1.php" method="post" enctype="multipart/form-data">
              <fieldset>
                <label><span class="text-form">Your Name:</span><span class="border">
                  <input class = "form-control" type="text" id="name" name="name" aria-describedby="name-format" required aria-required=”true” pattern="[.A-Za-z ]*" />
									 
                  </span></label>
                <label><span class="text-form">Your Email:</span><span class="border">
<input class = "form-control" type="email" name="email" id="email" aria-describedby="name-format" required aria-required=”true” />
									 
                  </span></label>
                <div class="wrapper">
                  <div class="text-form">Your Message:</div>
                  <div class="extra-wrap">
                    <div class="border">
                      <textarea id="area" name="area" aria-describedby="name-format" required aria-required=”true” pattern="[.A-Za-z ]*"></textarea>
                    </div>
                    <div class="clear"></div>
                     <div class="buttons"><input type="submit" placeholder="SEND" style="background-color:#d43400;  padding:5.5px 20px;line-height:1.23em; width:120px; color:#fff; position:fixed; left:550px; bottom:100px"> </input> 
                </div>
                  </div>
                </div>
              </fieldset>
            </form>
          </article>
          <article class="grid_4">
            <div class="indent-left2">
              <h3>Contact Information</h3>
              <figure class="img-indent-bot">
              <div id="googleMap" style="width:180px;height:240px;"><a href="https://www.google.co.in/maps/place/R.V.+College+Of+Engineering/@12.923424,77.499447,15z/data=!4m2!3m1!1s0x0:0x860a7edf6da62413"></a></div>
			  </figure>
			<dl>
                <dt>Mysore Road, R V Vidyanikethan, Bengaluru, Karnataka 560059</dt><br>
                <dd><span>Phone:</span>080671 78020</dd><br>
                <dd><span>Fax:</span> 91 - 080-67178011</dd><br>
                <dd><span>Email:</span> <a href="#"> principal@rvce.edu.in</a></dd><br>
              </dl>
            </div>
          </article>
        </div>
      </div>
    </div>
  </section>
</div>
           
<!--==============================footer=================================-->
<footer>
  <div class="main">
    <div class="aligncenter"> <span>Copyright &copy; Developed by Aparna Joshi and Apoorva N</div>
  </div>
</footer>
</body>
</html>