<?php
session_start();
if(!isset($_SESSION['email'])){
header("location:login.php");
exit;}
?>
<!--!DOCTYPE html-->
<html lang="en">
<head>
	<link id="page_favicon" href="images/favicon.ico" rel="icon" type="image/x-icon">
	<title>Blood Bank Management</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="css/my_reset.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/my_style.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/my_grid.css" type="text/css" media="screen">
	<script src="js/jquery-1.6.3.min.js" type="text/javascript"></script>
	<script src="js/tabs.js" type="text/javascript"></script>
	</head>
<body id="page3">
<div class="bg">
  <!--==============================header=================================-->
  <header>
    <div class="menu-row">
      <div class="main">
        <nav>
          <ul class="menu wrapper">
            <li><a href="index.php">Home Page</a></li>
            <li><a href="query.php">Ask For Blood</a></li>
            <li><a class="active" href="statistics.php">Statistics</a></li>
           <?php 
			if(isset($_SESSION['email'])){ //logged in ?>
				<li><a href="logout.php">Log out</a></li>
			<?php }else { ?>
				<li><a href="login.php">Log in</a></li>
			<?php } ?>	
            <li><a href="contacts.php">Contact Us</a></li>
          </ul>
        </nav>
      </div>
    </div>
	<div class="main">
      <div class="wrapper p3">
        <h1><a href="index.php">Blood Bank</a></h1>
        <form id="search-form" action="#" method="post" enctype="multipart/form-data">
          <fieldset>
            
          </fieldset>
        </form>
      </div>
    </div>
    <div class="row-bot"></div>
  </header>
  <!--==============================content================================-->
  
  <?php
/*
session_start();
if(!isset($_SESSION['email'])){
header("location:login.php");
exit;
}

*/
$hostname="localhost";
$username="root";
$password="root";
$database="bloodbank";
$con=mysqli_connect($hostname,$username,$password,$database);

?>

<!doctype html>
<center>
		<script src="js/Chart.min.js"></script>
	
		<div style="width: 50%">
			<canvas id="canvas" height="450" width="600"></canvas>
			
		</div>
		<u>Legend:</u>
		<div id="legend"></div>
	<script>
	var randomScalingFactor = function(){ return Math.round(Math.random()*100)};

	var barChartData = {
		labels : [
		<?php 
			$query="select distinct blood_group from donor order by blood_group asc";
			$result=mysqli_query($con,$query);
			$bgroups=array();
			while($row=mysqli_fetch_assoc($result)){
				echo   '"',$row['blood_group'].'", ';
				array_push($bgroups,$row['blood_group']);
			}
		?>
		],
		datasets : [ 
			{
				label: "Male",
				fillColor : "rgba(220,220,220,0.5)",
				strokeColor : "rgba(220,220,220,0.8)",
				highlightFill: "rgba(220,220,220,0.75)",
				highlightStroke: "rgba(220,220,220,1)",
				data : [//male
				<?php 
					foreach($bgroups as $bg){
						$query="select * from donor where blood_group='$bg' and gender='M'";
						$result=mysqli_query($con,$query);
						if($result)
							echo $result->num_rows.',';
						else
							echo "0,"; //just in case
					}
				
				?>
				]
			},
			{
				label: "Female",
				fillColor : "rgba(151,187,205,0.5)",
				strokeColor : "rgba(151,187,205,0.8)",
				highlightFill : "rgba(151,187,205,0.75)",
				highlightStroke : "rgba(151,187,205,1)",
				data : [//female
				<?php 
					foreach($bgroups as $bg){
						$query="select * from donor where blood_group='$bg' and gender='F'";
						$result=mysqli_query($con,$query);
						if($result)
							echo $result->num_rows.',';
						else
							echo "0,"; //just in case
					}
				
				?>
				]
			}
		],
		legendTemplate : "<ul class=\"<%=name.toLowerCase()%>-legend\"><% for (var i=0; i<datasets.length; i++){%><li><span style=\"background-color:<%=datasets[i].fillColor%>\"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>"

	}
	window.onload = function(){
		var ctx = document.getElementById("canvas").getContext("2d");
		window.myBar = new Chart(ctx).Bar(barChartData, {
			responsive : true
		});
		
		document.getElementById("legend").innerHTML=window.myBar.generateLegend();
	}

	</script>
	<br><br><br>
	
	<h3>Report for</h3> <div class="btn-wrap"> <span class="button"> <a href="querybyage.php"><strong>AGE</strong></a> </span> 
	  <span class="button"> <a href="querybybloodandarea.php"><strong>AREA and BLOODGROUP</strong></a> </span> 
	 	 <span class="button"> <a href="querybyweight.php"><strong>WEIGHT</strong></a> </span>
		 <span class="button"> <a href="queryfordetails.php"><strong>DETAILS</strong></a> </span>
		 <span class="button"> <a href="querybytime.php"><strong>TIMESTAMP</strong></a> </span>
		</div>
  
	</center>
	<!--==============================footer=================================-->
<footer>
  <div class="main">
    <div class="aligncenter"> <span>Copyright &copy; Developed by Aparna Joshi and Apoorva N</div>
  </div>
</footer>
</body>
</html>