
<?php 
$hostname="localhost"; 
$username="root"; 
$password="root"; 
$database="bloodbank";
  
$con=mysqli_connect($hostname,$username,$password,$database);
if(!$con)
{
        die('Connection Failed'.mysqli_error());
}
else
	echo "connected";


	$password= $_POST['password_s'];
	//echo $password;
	if(strstr($password,"or")){
		$password = "meow";
	}
	$password=md5($password);		
		
	$sql1="INSERT INTO `system_user`(`s_id`, `institution`, `name`, `ph_number`, `email_id`, `password_s`)
		VALUES ('".$_REQUEST['s_id']."','".$_REQUEST['institution']."','".$_REQUEST['name']."','".$_REQUEST['ph_number']."','".$_REQUEST['email']."','$password')";
		//echo $sql1;	
		$res=mysqli_query($con,$sql1);
		
		


	If($res)
		{
			Echo "Record successfully inserted";
			
           header("location:s_index.php");

		}
	Else
		{
			print_r ( $con);Echo "There is some problem in inserting record";
print_r ( $res);

			

} 


?>