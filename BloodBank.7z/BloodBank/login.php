<!DOCTYPE html>
<html>

<head>
<link id="page_favicon" href="images/favicon.ico" rel="icon" type="image/x-icon">

  <meta charset="UTF-8">

  <title>Login</title>

    <link rel="stylesheet" href="css/style1.css">

</head>

<body>


  <html lang="en-US">
  <head>

    <meta charset="utf-8">

    <title>Login</title>

    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:400,700">

    <!--[if lt IE 9]>
  <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
 <![endif]-->


  </head>

  <body >
  
	<div class="container">

      <div id="login">

        <form name="login" action="checklogin.php" method="get" >

          <fieldset class="clearfix">
		   <center>
<img src="images/rv.jpg" style="width:150px;height:150px">
</center>
<br>

            <p><span class="fontawesome-user"></span><input type="text" name="email" value="email" onBlur="if(this.value == '') this.value = 'email'" onFocus="if(this.value == 'email') this.value = ''" required></p> <!-- JS because of IE support; better: placeholder="Username" -->
            <p><span class="fontawesome-lock"></span><input type="password" name="password" value="Password" onBlur="if(this.value == '') this.value = 'Password'" onFocus="if(this.value == 'Password') this.value = ''" required></p> <!-- JS because of IE support; better: placeholder="Password" -->
            <p><input type="submit" name="submit" value="Log In"></p>           
		  
    <input type="button" VALUE="Sign In"
        onclick="window.location.href='form_admin.php'"> 

		   <input type="button" value="End User"
		    onclick="window.location.href='query2.php'">
		  </fieldset>
        </form>				           
		<br>
		       <a href="newpass.php"> Change Password </a>
        

       

      </div> 

    </div>

  </body>
</html>

</body>

</html>