<?php
session_start();
if(!isset($_SESSION['email'])){
header("location:login.php");
exit;
}

?>
<!--!DOCTYPE html-->
<html lang="en">
<head>
	<link id="page_favicon" href="images/favicon.ico" rel="icon" type="image/x-icon">
	<title>Blood Bank Management</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="css/style2.css">
	<link rel="stylesheet" href="css/my_reset.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/my_style.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/my_grid.css" type="text/css" media="screen">
	<script src="js/jquery-1.6.3.min.js" type="text/javascript"></script>
	<script src="js/tabs.js" type="text/javascript"></script>
	</head>
<body id="page1">
<div class="bg">

<header>
    
	
<?php
   			 
$hostname="localhost";
$username="root";
$password="root";
$database="bloodbank";
$con=mysqli_connect($hostname,$username,$password,$database);
            	?>
 
	
 <div class="main">
      <div class="wrapper p3">
        <h1><a href="login.php">Blood Bank</a></h1>
        
      </div>
    </div>
	</header>
 <form action = "" method = "post">
                                <div class="form-group">
                                	<div class="input-group">
   									 
   									 <?php
   									  if(isset($_POST['donorid']) && !isset($_POST['name']))
   										 {
											 //echo "hey if";
											  // echo $_POST['email_id'];
											  
   										 $query="select * from donor where d_id='{$_POST['donorid']}'";
   										 $result=mysqli_query($con,$query);
   										 $row=mysqli_fetch_assoc($result);
   										 ?>
   									 <select class = "form-control" name="donorid" >
                                        	<option value="<?php echo $_POST['donorid']; ?>" selected><?php echo $_POST['donorid']." ".$row['name']." ".$row['email_id']; ?> </option>
   									 </select>
<br>
   									 <input class = "form-control" type="text" name="name" aria-describedby="name-format" required aria-required=”true” pattern="[.A-Za-z ]*" value="<?php echo $row['name']; ?>" />
	<br>								 
   									 <input class = "form-control" type="text" maxlength="10" name="ph_number" required aria-describedby="name-format" required aria-required=”true” pattern="[789][0-9]{9}" value="<?php echo $row['ph_number'];	?>" />
		<br>							 
									 <input class = "form-control" type="email" name="email_id" required value="<?php echo $row['email_id'];	?>" />
			<br>						 
									 <input class = "form-control" type="date" name="dob" required value="<?php echo $row['dob'];	?>" />
				<br>	
				<input class = "form-control" type="text" maxlength="3" name="age" required aria-describedby="name-format" required aria-required=”true” pattern="[0-9]*" value="<?php echo $row['age'];	?>" />
						<br>				
						<!--<label>Gender
						<select class="border" name="gender" >
							
							<option value="M">M</option>
							<option value="F">F</option>						
						</select  value="<?php echo $row['gender'];	?>">
                </label>		<br> -->		
									<input class = "form-control" type="text" maxlength="1" name="gender" aria-describedby="name-format" required aria-required=”true” pattern="M||F" value="<?php echo $row['gender'];	?>" />
					<br>			 
						
				
<input class = "form-control" type="text" maxlength="3" name="blood_group"  aria-describedby="name-format" required aria-required=”true” pattern="(A|B|AB|O)[/+/-]" value="<?php echo $row['blood_group'];	?>" />
							<br>
									
							<!--<label>Area<select class="border" name="area">
							
							<option value="Bangalore North">Bangalore North</option>
							<option value="Bangalore South">Bangalore South</option>
							<option value="Bangalore East">Bangalore East</option>
							<option value="Bangalore West">Bangalore West</option>
				</select value="<?php echo $row['area'];	?>" >
                </label>	<br>	-->							
				<input class = "form-control" type="text" name="area" aria-describedby="name-format" required aria-required=”true” pattern="Bangalore North||Bangalore South||Bangalore East||Bangalore West" value="<?php echo $row['area'];	?>" />
								<br>
									 <br>
										
									<button type="submit" class="btn btn-lg btn-danger">MODIFY</button>	
   						 									
   									 <!-- similarly for all columns -->
   										 <?php
   										 
   										 }else if(isset($_POST['donorid']) && isset($_POST['name'])){
   										 //echo "hey elseif";
										 //echo $_REQUEST['email_id'];
   										 $query1="update donor set name= '{$_POST['name']}', ph_number='{$_POST['ph_number']}', email_id= '{$_POST['email_id']}', dob= '{$_POST['dob']}', age= '{$_POST['age']}', gender= '{$_POST['gender']}', blood_group= '{$_POST['blood_group']}', area= '{$_POST['area']}' where d_id='{$_POST['donorid']}' ";
										 
										 //echo $query1;
										 echo "Successfully Modified";
   										 $result1=mysqli_query($con,$query1);
										 //var_dump($con);
										 // $result2=mysqli_query($con,$query2);
   										 }   								 
   										 else {
   										 ?>
   										 
   										 
                                     	<select class = "form-control" name="donorid" onchange="document.forms[0].submit()">
                                        	<option value=0 selected disabled required>Choose a donor </option>
                                        	<?php
                                                	//$con=mysqli_connect($hostname,$username,$password,$database);
                                                	$query="SELECT d_id,name from donor";
                                                	$result=mysqli_query($con,$query);
                                                	while($row=mysqli_fetch_assoc($result))
                                                	{
                                                 	echo "<option value=".$row['d_id'].">".$row['d_id']." ".$row['name']."</option>";
                                                	}
                                                	mysqli_close();
                                        	?>
                                    	</select>
   									 
   									 <?php } ?>
                                	</div>
                            	</div>
                            	
                         	</form>
   						 <br>
							<form action="s_index.php" method="post">
   						 <button type="submit" class="btn btn-lg btn-danger">BACK</button>	 
                         	</form>

   						  </body>
</html>
