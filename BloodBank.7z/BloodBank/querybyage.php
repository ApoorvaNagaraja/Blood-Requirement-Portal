<?php
session_start();
if(!isset($_SESSION['email'])){
header("location:login.php");
exit;}
?>
<html lang="en">
<head>
	<link id="page_favicon" href="images/favicon.ico" rel="icon" type="image/x-icon">
	<title>Blood Bank Management</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="css/my_reset.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/my_style.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/my_grid.css" type="text/css" media="screen">
	<script src="js/jquery-1.6.3.min.js" type="text/javascript"></script>
	<script src="js/tabs.js" type="text/javascript"></script>
	</head>
<body id="page1">
<div class="bg">
<header>
<div class="main">
      <div class="wrapper p3">
        <h1><a href="login.php">Blood Bank</a></h1>
        
      </div>
    </div>
	</header>
	<center>
<h3>Report by age</h3>
                   
                        <form method="post" action="">
                            
								  Age <br/> from: <input type="number" name="fage" value="18" min="18" max="50" required /> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; to:
								   <input type="number" name="tage" value="50" min="18" max="50" required />
                                    <input type="submit"  />
									
                        </form>
                        <form method="get" action="statistics.php">
       <input type="submit" value="BACK" style="background-color:#00000;  padding:5px 4.5px;line-height:1.23em; width:100px; color:#fff; position:fixed; left:850px; bottom:366px"> </input> 
</form>											
						<br><br><br>
                <?php
                    if(isset($_POST['fage']) && isset($_POST['tage']))
                    {
                        $con=mysqli_connect("localhost","root","root","bloodbank");
                        if (!$con)
                        {
                            echo "Failed to connect to MySQL: " . mysqli_connect_error();
                            exit();
                        }
                        
                        echo "The query for ".$_POST['fage'].' to '.$_POST['tage']." are:<br/><br/>";
        
                        
						$query="SELECT * from donor where age between {$_POST['fage']} and {$_POST['tage']}";
						$result=mysqli_query($con,$query);
				   
                        if($result === FALSE ) 
                        {
                            echo "No one found!";
                        }
                        
                        else if(isset($result) and $result != FALSE)
                        {                       
                            if($result->num_rows>0)
                            {
                            ?>
                                <div>
                                <table border=1>
                                    
                                <thead>
                                    <tr>
										<th>ID</th>
                                        <th>Name</th>
										<th>Age</th>
                                        <th>Phone no.</th>
                                        <th>Email id</th>
                                        <th>DOB</th>
                                        <th>Gender</th>
										<th>blood_group</th>
										<th>Area</th>
										
                                    </tr>
                                </thead>

                            <?php
                            while($row = mysqli_fetch_assoc($result))
                            {
								//var_dump($row);
                                echo "<tr>";
                                echo "<td valign=middle align=center>" . $row['d_id'] . "</td>";
                                echo "<td valign=middle align=center>" . $row['name'] . "</td>";
								echo "<td valign=middle align=center>" . $row['age'] . "</td>";
                                echo "<td valign=middle align=center>" . $row['ph_number'] . "</td>";
								echo "<td valign=middle align=center>" . $row['email_id'] . "</td>";
								echo "<td valign=middle align=center>" . $row['dob'] . "</td>";
								echo "<td valign=middle align=center>" . $row['gender'] . "</td>";
								echo "<td valign=middle align=center>" . $row['blood_group'] . "</td>";
								echo "<td valign=middle align=center>" . $row['area'] . "</td>";
								
                                echo "</tr>";
                            }
                            echo "</table>";
                            echo "</div>";
                            echo "</div>";
                        }
                        else
                        echo "No entries!";
                    }
                    else
                    echo "No entries!";
                    mysqli_close($con); 
                }
                
    
                ?>
</center>
</body>
</html>
