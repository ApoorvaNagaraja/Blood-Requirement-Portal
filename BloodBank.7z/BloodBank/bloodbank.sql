-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 29, 2015 at 07:50 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bloodbank`
--

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE IF NOT EXISTS `address` (
  `d_no` varchar(10) NOT NULL DEFAULT '',
  `address_d` varchar(200) DEFAULT NULL,
  `d_id` varchar(10) NOT NULL DEFAULT '',
  `pincode` varchar(6) DEFAULT NULL,
  `state_no` varchar(5) NOT NULL DEFAULT '',
  PRIMARY KEY (`d_no`,`state_no`,`d_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`d_no`, `address_d`, `d_id`, `pincode`, `state_no`) VALUES
('', '', '', '', ''),
('12', '6th cross, basveshwarnagar', 'A3', '560124', '1'),
('12A', '8th cross, 9th block,jaynagar', 'B6', '560544', '1'),
('2', '3rd main, 5th cross, rajajinagar', 'A2', '560089', '1'),
('3', '24th cross, 3rd phase,kamalanagar', 'B5', '560509', '1'),
('343', '27th cross, kamalanagar', 'A8', '560299', '1'),
('45', '21st cross, kamalanagar', 'A5', '560194', '1'),
('45', '21st B cross,7th main, 2nd phase RT nagar', 'B4', '560474', '1'),
('56', '5th cross, jaynagar', 'A6', '560229', '1'),
('56', '14th cross, jaynagar', 'B3', '560439', '1'),
('6', '6th cross,near temple road, jaynagar', 'A9', '560334', '1'),
('87', '43rd cross, kamalanagar', 'B2', '560404', '1');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `a_id` varchar(10) NOT NULL,
  `institution` char(20) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `ph_number` varchar(20) DEFAULT NULL,
  `email_id` varchar(30) DEFAULT NULL,
  `password_a` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`a_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`a_id`, `institution`, `name`, `ph_number`, `email_id`, `password_a`) VALUES
('IS001', 'RVCE', 'Dr.Cauvery.N.K', '9972308043', 'cauverynk@rvce.edu.in', 'c00d2070337429dd5543e5546aac606b');

-- --------------------------------------------------------

--
-- Table structure for table `appends`
--

CREATE TABLE IF NOT EXISTS `appends` (
  `d_id` varchar(10) NOT NULL DEFAULT '',
  `s_id` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`d_id`,`s_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `blood`
--

CREATE TABLE IF NOT EXISTS `blood` (
  `b_code` varchar(10) NOT NULL DEFAULT '',
  `d_id` varchar(10) NOT NULL DEFAULT '',
  `date_of_donation` date DEFAULT NULL,
  PRIMARY KEY (`d_id`,`b_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blood`
--

INSERT INTO `blood` (`b_code`, `d_id`, `date_of_donation`) VALUES
('102', 'A2', '2015-01-17'),
('103', 'A3', '2015-01-17'),
('105', 'A5', '2015-03-17'),
('106', 'A6', '2015-01-17'),
('108', 'A8', '2015-01-17'),
('109', 'A9', '2015-03-17'),
('111', 'B2', '2015-03-17'),
('112', 'B3', '2015-01-17'),
('113', 'B4', '2015-01-17'),
('114', 'B5', '2015-01-17'),
('115', 'B6', '2015-01-17');

-- --------------------------------------------------------

--
-- Table structure for table `donates`
--

CREATE TABLE IF NOT EXISTS `donates` (
  `d_id` varchar(10) NOT NULL DEFAULT '',
  `b_code` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`b_code`,`d_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `donor`
--

CREATE TABLE IF NOT EXISTS `donor` (
  `d_id` varchar(10) NOT NULL DEFAULT '',
  `name` varchar(50) DEFAULT NULL,
  `ph_number` varchar(20) DEFAULT NULL,
  `email_id` varchar(30) DEFAULT NULL,
  `dob` timestamp NULL DEFAULT NULL,
  `gender` char(10) DEFAULT NULL,
  `age` int(5) DEFAULT NULL,
  `blood_group` varchar(5) DEFAULT NULL,
  `area` varchar(20) DEFAULT NULL,
  `a_id` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`a_id`,`d_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donor`
--

INSERT INTO `donor` (`d_id`, `name`, `ph_number`, `email_id`, `dob`, `gender`, `age`, `blood_group`, `area`, `a_id`) VALUES
('2333fff', 'Apoorva', '9611939150', 'apoorvanagaraj95@gmail.com', '1995-01-01 18:30:00', 'F', 20, 'O+', '32436546', ''),
('A6', 'V MAMTHA', '9845098756', 'spoo@hotspot.com', '2015-04-14 18:30:00', 'F', 34, 'O+', 'bangalore_south', ''),
('B2', 'THIPPA REDDY', '9591378807', 'aparna@yahoo.com', '2015-03-30 18:30:00', 'M', 39, 'B+', 'bangalore_east', ''),
('A66', 'Aparnajoshi', '9738692465', 'aparnajoshi.88@gmail.com', '1995-02-20 18:30:00', 'F', 20, 'O+', 'Bangalore North', '112'),
('2333', 'Apoorva', '96119391506', 'apoorvanagaraj95@gmail.com', '1995-01-01 18:30:00', 'F', 20, 'O+', 'Bangalore North', '32436546'),
('v', 'v', '9738128164', 'aparna@yahoo.com', '2015-04-01 18:30:00', 'F', 27, 'B+', 'Bangalore North', '4'),
('r', 'rr', '9738128164', 'aparna@yahoo.com', '2015-05-04 18:30:00', 'M', 27, 'n', 'Bangalore North', 'fffd'),
('46546', 'V', '9738020105', 'vinayjoshi.75@gmail.com', '1988-05-06 18:30:00', 'm', 27, 'O+', 'Bangalore North', 'fggnm'),
('fff', 'ffff', '8050078123', 'spoo@hotspot.com', '2015-03-31 18:30:00', 'F', 33, 'B+', 'Bangalore North', 'hoih'),
('3245166', 'fgf', '9738128164', 'spoo@hotspot.com', '2015-05-21 18:30:00', 'M', 27, 'aa', 'dvvb', 'IS001'),
('A2', 'DR. RADHA KRISHNA', '9886127398', 'aparna@yahoo.com', '2015-04-21 18:30:00', 'M', 47, 'A+', 'Bangalore', 'IS001'),
('A9', 'MANONMANI  .S ', '8050078123', 'spoo@hotspot.com', '2015-04-08 18:30:00', 'F', 33, 'B+', 'bangalore_north', 'IS001'),
('B3', 'CHANDRAMI C', '9743752234', 'spoo@hotspot.com', '2015-04-13 18:30:00', 'F', 35, 'O+', 'Bangalore South', 'IS001'),
('B4', 'VENUGOPAL G', '8123944950', 'apoo@gmail.com', '0000-00-00 00:00:00', 'M', 30, 'O+', 'bangalore_north', 'IS001'),
('B5', 'GEETHAKS', '9900700990', 'aparna@yahoo.com', '2015-04-07 18:30:00', 'f', 45, 'A+', 'bangalore_south', 'IS001'),
('B6', 'DR B RADHAKRISHNA', '9247169978', 'spoo@hotspot.com', '0000-00-00 00:00:00', 'M', 16, 'O-', 'bangalore_east', 'IS001');

-- --------------------------------------------------------

--
-- Table structure for table `donor_details`
--

CREATE TABLE IF NOT EXISTS `donor_details` (
  `d_id` varchar(10) NOT NULL DEFAULT '',
  `height` decimal(5,3) DEFAULT NULL,
  `weight` decimal(10,3) DEFAULT NULL,
  `bmi` decimal(10,3) NOT NULL DEFAULT '0.000',
  PRIMARY KEY (`d_id`,`bmi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `donor_details`
--

INSERT INTO `donor_details` (`d_id`, `height`, `weight`, `bmi`) VALUES
('1', '5.600', '50.000', '21.000'),
('10', '5.400', '46.000', '4.000'),
('11', '5.800', '78.000', '35.000'),
('12', '5.100', '67.000', '3.000'),
('13', '5.500', '43.000', '3.000'),
('14', '5.300', '42.000', '332.000'),
('15', '5.000', '40.000', '43.000'),
('2', '5.700', '60.000', '21.000'),
('3', '5.800', '70.000', '3446.000'),
('4', '6.200', '78.000', '455.000'),
('5', '5.110', '68.000', '345.000'),
('6', '5.800', '79.000', '4.000'),
('7', '5.300', '64.000', '67.000'),
('8', '5.400', '67.000', '56.000'),
('9', '5.500', '53.000', '4.000'),
('A2', '5.700', '60.000', '21.000'),
('A3', '5.800', '70.000', '3446.000'),
('A5', '5.110', '68.000', '345.000'),
('A6', '5.800', '79.000', '4.000'),
('A8', '5.400', '67.000', '56.000'),
('A9', '5.500', '53.000', '4.000'),
('B2', '5.800', '78.000', '35.000'),
('B3', '5.100', '67.000', '3.000'),
('B4', '5.500', '43.000', '3.000'),
('B5', '5.300', '42.000', '332.000'),
('B6', '5.000', '40.000', '43.000');

-- --------------------------------------------------------

--
-- Table structure for table `modify_blood`
--

CREATE TABLE IF NOT EXISTS `modify_blood` (
  `d_id` varchar(10) NOT NULL DEFAULT '',
  `a_id` varchar(10) NOT NULL DEFAULT '',
  `bmi` decimal(10,3) NOT NULL DEFAULT '0.000',
  PRIMARY KEY (`a_id`,`d_id`,`bmi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE IF NOT EXISTS `state` (
  `state_no` varchar(5) NOT NULL,
  `state` char(20) DEFAULT NULL,
  PRIMARY KEY (`state_no`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`state_no`, `state`) VALUES
('', ''),
('1', 'karnataka');

-- --------------------------------------------------------

--
-- Table structure for table `system_user`
--

CREATE TABLE IF NOT EXISTS `system_user` (
  `s_id` varchar(10) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `institution` char(20) DEFAULT NULL,
  `ph_number` varchar(20) DEFAULT NULL,
  `email_id` varchar(30) DEFAULT NULL,
  `password_s` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`s_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `system_user`
--

INSERT INTO `system_user` (`s_id`, `name`, `institution`, `ph_number`, `email_id`, `password_s`) VALUES
('aa', 'Aa', 'aa', '9738128164', 'aparnajoshi.88@gmail.com', 'a'),
('aaa', 'aa', 'aaa', '9738128164', 'aa@a.com', '0cc175b9c0f1b6a831c399e269772661'),
('ff', 'ffbfb', 'ff', '9738128164', 'erynk@rvce.edu.in', 'ff06d4e6f72ffef5af8abff13e3a60b1'),
('ffffff', 'ffbfb', 'ff', '9738128164', 'cauverynk@rvce.edu.in', 'c00d2070337429dd5543e5546aac606b'),
('hh', 'hh', 'hh', '9738128164', 'hh@hh.com', '73c18c59a39b18382081ec00bb456d43'),
('IS011', 'Geetha V', 'RVCE', '988104374', 'geethav@rvce.edu.in', '57015c1e8cb6c6d0c95f01303d5c6541');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
