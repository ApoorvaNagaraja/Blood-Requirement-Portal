<?php
session_start();

$hostname="localhost"; 
$username="root"; 
$password="root"; 
$database="bloodbank";
  
$con=mysqli_connect($hostname,$username,$password,$database);
if(!$con)
{
        die('Connection Failed'.mysqli_error());
}



// username and password sent from form 
$email=$_REQUEST['email']; 
$old_password=$_REQUEST['old_password']; 
$old_password=md5($old_password);
$new_password=$_REQUEST['new_password']; 
$new_password=md5($new_password);
// To protect MySQL injection (more detail about MySQL injection)
$email = stripslashes($email);
$old_password = stripslashes($old_password);
$new_password = stripslashes($new_password);

$sql="SELECT name FROM admin WHERE email_id='$email' and password_a='$old_password'";

$result=mysqli_query($con,$sql);
	
// Mysql_num_row is counting table row
$count=mysqli_num_rows($result);
// Mysql_num_row is counting table row
if($count==1)
{
//echo $new_password;
 $query="update admin set password_a= '$new_password' where password_a='$old_password' ";
//echo $query;
$res1=mysqli_query($con,$query);
										 
header("Location:login.php");

}
else
{
	
$sql1="SELECT name FROM system_user WHERE email_id='$email' and password_s='$old_password'";



$result1=mysqli_query($con,$sql1);
// Mysql_num_row is counting table row
$count1=mysqli_num_rows($result1);



// Mysql_num_row is counting table row
if($count1==1)
{
$query1="update system_user set password_s= '$new_password' where password_s='$old_password' ";
//echo $query;
$res2=mysqli_query($con,$query1);
										 

header("Location:login.php");
}

else {
echo "Wrong Username or Password";
}


}






	

?>