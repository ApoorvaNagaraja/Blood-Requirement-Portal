<?php
session_start();
if(!isset($_SESSION['email'])){
header("location:login.php");
exit;}
?>
<html lang="en">
<head>
	<link id="page_favicon" href="images/favicon.ico" rel="icon" type="image/x-icon">
	<title>Blood Bank Management</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="css/my_reset.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/my_style.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/my_grid.css" type="text/css" media="screen">
	<script src="js/jquery-1.6.3.min.js" type="text/javascript"></script>
	<script src="js/tabs.js" type="text/javascript"></script>
	</head>
<body id="page1">
<div class="bg">
<header>
<div class="main">
      <div class="wrapper p3">
        <h1><a href="login.php">Blood Bank</a></h1>
        
      </div>
    </div>
	</header>
	<center>
<h3>Report by Weight </h3>
                   
                        <form method="post" action="">
                            
								  Weight above <br/> <input type="number" name="weight" value="50" min="50" max="100" required /> 
								  
                                    <input type="submit"  />
                        </form>
						<form method="get" action="statistics.php">
    <input type="submit" value="BACK" style="background-color:#00000;  padding:5px 4.5px;line-height:1.23em; width:100px; color:#fff; position:fixed; left:850px; bottom:367px"> </input> 
</form>	      <br><br><br><br>
                <?php
                    if(isset($_POST['weight']))
                    {
                        $con=mysqli_connect("localhost","root","root","bloodbank");
                        if (!$con)
                        {
                            echo "Failed to connect to MySQL: " . mysqli_connect_error();
                            exit();
                        }
                        
                        echo "The query for ".$_POST['weight']." are:<br/><br/>";
						
						
						$query="select * from donor left join donor_details on donor.d_id = donor_details.d_id  
						where donor_details.weight>='{$_POST['weight']}'";
                        
						//$query="SELECT * from donor_details where weight = '{$_POST['weight']}'";
						//echo $query;
						$result=mysqli_query($con,$query);
				   
                     /*   if($result === FALSE ) 
                        {
                            echo "No one found!";
                        }
                        
                        else */ if(isset($result) and $result != FALSE)
                        {                       
                            if($result->num_rows>0)
                            {
                            ?>
                                <div>
                                <table border=1>
                                    
                                <thead>
                                    <tr>
										<th>ID</th>
										<th>Name</th>
										<th>Phone Number</th>
										<th>E-mail</th>
                                        <th>Height</th>
										<th>Weight</th>
                                        <th>BMI</th>
                                        
                                    </tr>
                                </thead>

                            <?php
                            while($row = mysqli_fetch_assoc($result))
                            {
							
								//var_dump($row);
                                echo "<tr>";
                                echo "<td valign=middle align=center>" . $row['d_id'] . "</td>";
								echo "<td valign=middle align=center>" . $row['name'] . "</td>";
								echo "<td valign=middle align=center>" . $row['ph_number'] . "</td>";
								echo "<td valign=middle align=center>" . $row['email_id'] . "</td>";
                                echo "<td valign=middle align=center>" . $row['height'] . "</td>";
								echo "<td valign=middle align=center>" . $row['weight'] . "</td>";
                                echo "<td valign=middle align=center>" . $row['bmi'] . "</td>";
                                echo "</tr>";
                            }
                            echo "</table>";
                            echo "</div>";
                            echo "</div>";
                        }
                        else
                        echo "No entries!";
                    }
                    else
                    echo "No entries!";
                    mysqli_close($con); 
                }
                
    
                ?>
</center>
</body>
</html>
