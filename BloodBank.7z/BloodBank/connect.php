<?php
$hostname="localhost"; 
$username="root"; 
$password="root"; 
$database="bloodbank";
  
$con=mysqli_connect($hostname,$username,$password,$database);
if(! $con)
{
        die('Connection Failed'.mysqli_connect_error());
}
else
print_r ( $con);

?>
