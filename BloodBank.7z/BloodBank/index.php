<?php
session_start();
if(!isset($_SESSION['email'])){
header("location:login.php");
exit;}
?>
<!--!DOCTYPE html-->
<html lang="en">
<head>
	<link id="page_favicon" href="images/favicon.ico" rel="icon" type="image/x-icon">
	<title>Blood Bank Management</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="css/my_reset.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/my_style.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/my_grid.css" type="text/css" media="screen">
	<script src="js/jquery-1.6.3.min.js" type="text/javascript"></script>
	<script src="js/tabs.js" type="text/javascript"></script>
	</head>
<body id="page1">
<div class="bg">
  <!--==============================header=================================-->
  <header>
    <div class="menu-row">
      <div class="main">
        <nav>
          <ul class="menu wrapper">
            <li><a class="active" href="index.php">Home Page</a></li>
            <li><a href="query.php">Ask for Blood</a></li>
            <li><a href="statistics.php">Statistics</a></li>
			<?php 
			if(isset($_SESSION['email'])){ //logged in ?>
				<li><a href="logout.php">Log out</a></li>
			<?php }else { ?>
				<li><a href="login.php">Log in</a></li>
			<?php } ?>	
            <li><a href="contacts.php">Contact Us</a></li>
          </ul>
        </nav>
      </div>
    </div>
	<div class="main">
      <div class="wrapper p3">
        <h1><a href="index.php">Blood Bank</a></h1>
        <form id="search-form" action="#" method="post" enctype="multipart/form-data">
          <fieldset>
            
          </fieldset>
        </form>
      </div>
    </div>
	<ul class="tabs">
      <li><a href="#tab1">Insert</a></li>
      <li><a href="#tab2">Modify</a></li>
      <li><a href="#tab3">Delete</a></li>
    </ul>
	<div class="tab_container">
      <div id="tab1" class="tab_content">
        <div class="main">
          <div class="wrapper">
            <figure class="img-indent-r"><img src="images/insert.jpg" alt=""></figure>
            <div class="extra-wrap">
              <div class="indent"> <strong class="title">Insert</strong>
                <p class="p5"> Details of a new donor<br><br><br>
                  
				  </p><br>
                   <div class="btn-wrap"> <span class="button"> <a href="test.php"><strong>Select File</strong></a> </span> </div>
				   <div class="btn-wrap"> <span class="button"> <a href="manual.php"><strong>Manual Entry</strong></a> </span> </div>
				</form>   
              </div>
            </div>
          </div>
        </div>
      </div>
      <div id="tab2" class="tab_content">
        <div class="main">
          <div class="wrapper">
            <figure class="img-indent-r"><img src="images/modify.png" alt=""></figure>
            <div class="extra-wrap">
              <div class="indent"> <strong class="title">Modify</strong>
                <p class="p5">Details of an existing donor<br><br><br>
                To modify
				</p><br>
                <div class="btn-wrap"> <span class="button"> <a href="modify.php"><strong>Click Here</strong></a> </span> </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div id="tab3" class="tab_content">
        <div class="main">
          <div class="wrapper">
            <figure class="img-indent-r"><img src="images/delete.jpg" alt=""></figure>
            <div class="extra-wrap">
              <div class="indent"> <strong class="title">Delete</strong>
                <p class="p5">Details of an existig donor<br><br><br>
                  To delete
				  </p><br>
                <div class="btn-wrap"> <span class="button"> <a href="delete.php"><strong>Click Here</strong></a>
				
				</span> </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </header>
	  <!--==============================content================================-->
  <section id="content">
    <div class="main">
      <div class="container_12">
        <div class="wrapper img-indent-bot">
          <article class="grid_4">
            <h3>Blood Donation Tips</h3>
            <ul class="list-1">
              <li><a href="#">Get a good night's sleep.</a></li>
              <li><a href="#">Drink an extra 16 oz. of water.</a></li>
              <li><a href="#">Eat a healthy meal before your donation.</a></li>
              <li><a href="#">Drink an extra four glasses of liquids after donating.</a></li>
            </ul>
          </article>
          <article class="grid_8">
		  <?php 
			if(isset($_SESSION['email'])){ //logged in
			echo "<h2>Hi <i>{$_SESSION['name']}</i>!</h2>";
			 }
		    ?>
            <h2>Welcome to Blood Bank!</h2>
            <div class="wrapper prev-indent-bot">
              <figure class="img-indent2"><img src="images/blood_donation.jpg" alt=""></figure>
              <div class="extra-wrap">
                <h6 class="p1">Blood donation Management </h6> This project aims at meeting the emergency blood requirements in Bangalore city.
				Every day hundreds of people in our communities need blood - and there is no substitute for it. 
				This project provides the critical link between potential blood donors who generously give 
				the gift of life and the local patients who need this lifesaving gift.
				</div>
            </article>
        </div>
      </div>
    </div>
  </section>
</div>
<!--==============================footer=================================-->
<footer>
  <div class="main">
    <div class="aligncenter"> <span>Copyright &copy; Developed by Aparna Joshi and Apoorva N</div>
  </div>
</footer>
</body>
</html>