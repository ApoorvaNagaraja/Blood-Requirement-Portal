<?php

//$salt ='whatever_you_want';

    function encr($text)
    {
        return trim(base64_encode(mcrypt_encrypt(MCRYPT_RIJNDAEL_256, '“»àÜÄ^l0úÖuŠ­q', $text, MCRYPT_MODE_ECB, mcrypt_create_iv(mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB), MCRYPT_RAND))));
    }
	$v="";
	if(isset($_REQUEST['v'])){
		$v=$_REQUEST['v'];
		echo "<h3>".encr($_REQUEST['v'])."<h3>";
	}
		
?>
		<form action=" " method="post">
			<input type="text" name="v" value="<?php echo $v; ?>" />
			<input type="submit" />
		</form>