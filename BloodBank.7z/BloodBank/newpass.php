<!DOCTYPE html>
<html>

<head>
<link id="page_favicon" href="images/favicon.ico" rel="icon" type="image/x-icon">

  <meta charset="UTF-8">

  <title>change password</title>

    <link rel="stylesheet" href="css/style1.css">

</head>

<body>

  <html lang="en-US">
  <head>

    <meta charset="utf-8">

    <title>change password</title>

    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:400,700">

    <!--[if lt IE 9]>
  <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
 <![endif]-->

  </head>

  <body >
  
	<div class="container">

      <div id="login">

        <form name="login" action="changepassword.php" method="get" >

          <fieldset class="clearfix">

            <p><span class="fontawesome-user"></span><input type="text" name="email" value="email" onBlur="if(this.value == '') this.value = 'email'" onFocus="if(this.value == 'email') this.value = ''" required></p> <!-- JS because of IE support; better: placeholder="Username" -->
            <p><span class="fontawesome-lock"></span><input type="password" name="old_password" value="old_Password" onBlur="if(this.value == '') this.value = 'old_Password'" onFocus="if(this.value == 'old_Password') this.value = ''" required></p> <!-- JS because of IE support; better: placeholder="Password" -->
            <p><span class="fontawesome-lock"></span><input type="password" name="new_password" value="new_Password" onBlur="if(this.value == '') this.value = 'new_Password'" onFocus="if(this.value == 'new_Password') this.value = ''" required></p> <!-- JS because of IE support; better: placeholder="Password" -->
            
			<p><input type="submit" name="submit" value="change password"></p>           
	</div>

  </body>
</html>

</body>

</html>