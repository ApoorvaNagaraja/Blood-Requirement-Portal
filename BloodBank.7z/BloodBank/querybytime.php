<?php
session_start();
if(!isset($_SESSION['email'])){
header("location:login.php");
exit;}
?>
<html lang="en">
<head>
	<link id="page_favicon" href="images/favicon.ico" rel="icon" type="image/x-icon">
	<title>Blood Bank Management</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="css/my_reset.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/my_style.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/my_grid.css" type="text/css" media="screen">
	<script src="js/jquery-1.6.3.min.js" type="text/javascript"></script>
	<script src="js/tabs.js" type="text/javascript"></script>
	</head>
<body id="page1">
<div class="bg">
<header>
<div class="main">
      <div class="wrapper p3">
        <h1><a href="login.php">Blood Bank</a></h1>
        
      </div>
    </div>
	</header>
	<center>
<h3>Query</h3>
                   
                            
								  Donors who hasn't donated blood for last three months are <br/> 
								   <form method="get" action="statistics.php">
    <input type="submit" value="BACK" style="background-color:#00000;  padding:5px 4.5px;line-height:1.23em; width:100px; color:#fff; position:fixed; left:900px; bottom:335px"> </input> 
</form>					
                        
                <br><br><br><br>
                <?php
                        $con=mysqli_connect("localhost","root","root","bloodbank");
                        if (!$con)
                        {
                            echo "Failed to connect to MySQL: " . mysqli_connect_error();
                            exit();
                        }
                        
                        
					 $id= date("y-m-d",strtotime("-3 Months"));
					 
					      
						$query="select d.name as name, d.blood_group as blood_group from donor as d
						join blood as b on d.d_id=b.d_id
						where 'b.date_of_donation'<=$id;";
                  
						
						$result=mysqli_query($con,$query);
				   
                       if($result === FALSE ) 
                        {
                            echo "No one found!";
                        }
                        
                        else if(isset($result) and $result != FALSE)
                        {                       
                            if($result->num_rows>0)
                            {
                            ?>
                                <div>
                                <table border=1>
                                    
                                <thead>
                                    <tr>
										<th>Name</th>
										<th>Blood Group</th>
										
                                    </tr>
                                </thead>

                            <?php
                            while($row = mysqli_fetch_assoc($result))
                            {
							
								//var_dump($row);
                                echo "<tr>";
                                echo "<td valign=middle align=center>" . $row['name'] . "</td>";
								echo "<td valign=middle align=center>" . $row['blood_group'] . "</td>";
								
								echo "</tr>";
                            }
                            echo "</table>";
                            echo "</div>";
                            echo "</div>";
                        }
                        else
                        echo "No entries!";
                    }
                    else
                    echo "No entries!";
                    mysqli_close($con); 
                
               
    
                ?>
</center>
</body>
</html>
