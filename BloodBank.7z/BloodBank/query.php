<?php
session_start();
if(!isset($_SESSION['email'])){
header("location:login.php");
exit;}
?>
<!--!DOCTYPE html-->
<html lang="en">
<head>
	<link id="page_favicon" href="images/favicon.ico" rel="icon" type="image/x-icon">
	<title>Blood Bank Management</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="css/my_reset.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/my_style.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/my_grid.css" type="text/css" media="screen">
	<script src="js/jquery-1.6.3.min.js" type="text/javascript"></script>
	<script src="js/tabs.js" type="text/javascript"></script>

	</head>
	
<body id="page2">
<div class="bg">
  <!--==============================header=================================-->
  <header>
    <div class="menu-row">
      <div class="main">
        <nav>
          <ul class="menu wrapper">
            <li><a href="index.php">Home Page</a></li>
            <li><a class="active" href="query.php">Ask For Blood</a></li>
            <li><a href="statistics.php">Statistics</a></li>
            <?php 
			if(isset($_SESSION['email'])){ //logged in ?>
				<li><a href="logout.php">Log out</a></li>
			<?php }else { ?>
				<li><a href="login.php">Log in</a></li>
			<?php } ?>	
            <li><a href="contacts.php">Contact us</a></li>
          </ul>
        </nav>
      </div>
    </div>
	<div class="main">
      <div class="wrapper p3">
        <h1><a href="index.php">Blood Bank</a></h1>
        <form id="search-form" action="#" method="post" enctype="multipart/form-data">
          <fieldset>
            
          </fieldset>
        </form>
      </div>
    </div>
    <div class="row-bot"></div>
  </header>
  <!--==============================content================================-->
<section id="content">   
   <div class="main">
         <div class="container_12">
            <div class="wrapper">
			 <article class="grid_8">
	        <h3>Ask for Blood</h3>
            <form id="contact-form" action="send.php" method="post">
			<label><input id="name" name="name" value=""  placeholder="Name" aria-describedby="name-format" required aria-required=”true” pattern="[A-Za-z]+||[A-Za-z]+\s[A-Za-z]+">
            </label>
            <label><input type="email" name="email" placeholder="E-mail" required>
            </label>
			<label><input type="text" name="phno" placeholder="Phone Number" required aria-describedby="name-format" required aria-required=”true” pattern="[789][0-9]{9}"/>
            </label>
			<label>Blood Group
                    <select class="border" name="bloodgroup" >
							<!--<option >Blood Group</option>-->
							<option value="O+">O+</option>
							<option value="O-">O-</option>
							<option value="B+">B+</option>
							<option value="B-">B-</option>
							<option value="AB+">AB+</option>
							<option value="AB-">AB-</option>
							<option value="A+">A+</option>
							<option value="A-">A-</option>
				</select>
                </label>
				<label><input type="text" name="hospital" placeholder="Hospital Name" aria-describedby="name-format"  aria-required=”true” pattern="[A-Za-z]+||[A-Za-z]+\s[A-Za-z]+">
				</label>
				<label>Area:<select class="border" name="area">
							<option value="Bangalore North">Bangalore North</option>
							<option value="Bangalore South">Bangalore South</option>
							<option value="Bangalore East">Bangalore East</option>
							<option value="Bangalore West">Bangalore West</option>
				</select>
                </label>
				<label>
                  <textarea id="name" placeholder="Blood required at" required></textarea></label>
				 
                <input type="submit" value="SEND" style="background-color:#d43400;  padding:5.5px 20px;line-height:1.23em; width:120px; color:#fff; position:fixed; left:750px; bottom:125px"> </input> 
                 
				
                 	</form>
					</article>
			</div>
	     </div>
		 </div>
		</section>
  <!--==============================footer=================================-->

  <footer> 
 <div class="main">
 <div class="aligncenter">
   <span>    <br><br><br><br>Copyright &copy; Developed by Aparna Joshi and Apoorva N</span>
  </div>
  </div>
  </footer>

  </body>
</html>