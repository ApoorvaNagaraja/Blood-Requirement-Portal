<?php
session_start();
if(!isset($_SESSION['email'])){
header("location:login.php");
exit;}
?>
<html lang="en">
<head>
	<link id="page_favicon" href="images/favicon.ico" rel="icon" type="image/x-icon">
	<title>Blood Bank Management</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="css/my_reset.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/my_style.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/my_grid.css" type="text/css" media="screen">
	<script src="js/jquery-1.6.3.min.js" type="text/javascript"></script>
	<script src="js/tabs.js" type="text/javascript"></script>
	</head>
<body id="page1">
<div class="bg">
<header>
<div class="main">
      <div class="wrapper p3">
        <h1><a href="login.php">Blood Bank</a></h1>
        
      </div>
    </div>
	</header>
	<center>
<h3>DETAILS</h3>
                   
                        <form method="post" action="">
								<select class = "form-control" name="donorid" >
                                        	<option value=0 selected disabled required>Choose a donor </option>
                                        	<?php
											$hostname="localhost";
											$username="root";
											$password="root";
											$database="bloodbank";

                                                	$con=mysqli_connect($hostname,$username,$password,$database);
                                                	$query="SELECT d_id,name from donor";
                                                	$result=mysqli_query($con,$query);
                                                	while($row=mysqli_fetch_assoc($result))
                                                	{
                                                 	echo "<option value=".$row['d_id'].">".$row['d_id']." ".$row['name']."</option>";
                                                	}
                                                	mysqli_close();
                                        	?>
                                    	</select>
								<br>  
                                    <input type="submit"  />
                        </form>
						<form method="get" action="statistics.php">
    <input type="submit" value="BACK" style="background-color:#00000;  padding:5px 4.5px;line-height:1.23em; width:100px; color:#fff; position:fixed; left:750px; bottom:365px"> </input> 
</form>						
                <br><br><br><br>
				
               
				
				<?php						 
	 
$hostname="localhost";
$username="root";
$password="root";
$database="bloodbank";
                	$con=mysqli_connect($hostname,$username,$password,$database);
					if(isset($_POST['donorid']))
					{
					
                		$id=$_POST['donorid'];
                    	 //echo $id;

				        
                   		  echo "The query for details with donor_id "; echo $id; echo "are:<br/><br/>";
						
						$query="select d.name as name, d.ph_number as ph_number, d.email_id as email_id, dd.height as height, dd.weight as weight, 
						dd.bmi as bmi, a.d_no as d_no, a.address_d as address_d 
						from donor as d 
						join donor_details as dd on d.d_id = dd.d_id 
						join address as a on d.d_id=a.d_id
						where d.d_id='$id';";
                        echo $query;
						
						//$query="SELECT * from donor_details where weight = '{$_POST['weight']}'";
						//echo $query;
						$result=mysqli_query($con,$query);
				   
                        if($result === FALSE ) 
                        {
                            echo "No one found!";
                        }
                        
                    elseif(isset($result) and $result != FALSE)
                    {                       
                        if($result->num_rows>0)
                        {
                            ?>
                                <div>
                                <table border=1>
                                    
                                <thead>
                                    <tr>
										<th>Name</th>
										<th>Phone Number</th>
										<th>E-mail</th>
                                        <th>Height</th>
										<th>Weight</th>
                                        <th>BMI</th>
										<th>DOOR NO</th>
										<th>ADDRESS</th>
                                        
                                    </tr>
                                </thead>

                            <?php
                            while($row = mysqli_fetch_assoc($result))
                            {
							
								//var_dump($row);
                                echo "<tr>";
                                echo "<td valign=middle align=center>" . $row['name'] . "</td>";
								echo "<td valign=middle align=center>" . $row['ph_number'] . "</td>";
								echo "<td valign=middle align=center>" . $row['email_id'] . "</td>";
                                echo "<td valign=middle align=center>" . $row['height'] . "</td>";
								echo "<td valign=middle align=center>" . $row['weight'] . "</td>";
                                echo "<td valign=middle align=center>" . $row['bmi'] . "</td>";
								echo "<td valign=middle align=center>" . $row['d_no'] . "</td>";
								echo "<td valign=middle align=center>" . $row['address_d'] . "</td>";
                                echo "</tr>";
                            }
                            echo "</table>";
                            echo "</div>";
                            echo "</div>";
                        }
                        else
                        echo "No entries!";
                    }
                    else
                    echo "No entries!"; 
                    mysqli_close($con); 
               
                
				}
    
                ?>
</center>
</body>
</html>
