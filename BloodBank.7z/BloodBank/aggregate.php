<?php
session_start();
if(!isset($_SESSION['email'])){
header("location:login.php");
exit;}
?>
<html lang="en">
<head>
	<link id="page_favicon" href="images/favicon.ico" rel="icon" type="image/x-icon">
	<title>Blood Bank Management</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="css/my_reset.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/my_style.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/my_grid.css" type="text/css" media="screen">
	<script src="js/jquery-1.6.3.min.js" type="text/javascript"></script>
	<script src="js/tabs.js" type="text/javascript"></script>
	</head>
<body id="page1">
<div class="bg">
<header>
<div class="main">
      <div class="wrapper p3">
        <h1><a href="login.php">Blood Bank</a></h1>
        
      </div>
    </div>
	</header>
	<center>
<h3>Query by blood group and area</h3>
                   
                        <form method="post" action="">
                            
								  BLOOD GROUP 
				    <label><span class="text-form"></span><span class="border">
                    <select class="border" name="blood_group">
							<option value="O+">O+</option>
							<option value="O-">O-</option>
							<option value="B+">B+</option>
							<option value="B-">B-</option>
							<option value="AB+">AB+</option>
							<option value="AB-">AB-</option>
							<option value="A+">A+</option>
							<option value="A-">A-</option>
				    </select>
                    </span></label>								  <br><br><br>

								  
                                    <input type="submit"  />
                        </form>
						<br><br><br>
                
                <?php
                    if(isset($_POST['blood_group']))
                    {
                        $con=mysqli_connect("localhost","root","root","bloodbank");
                        if (!$con)
                        {
                            echo "Failed to connect to MySQL: " . mysqli_connect_error();
                            exit();
                        }
                        
                        $bg= $_POST['blood_group'];
						echo 'Blood group selected : '.$bg.'<br>';
						$query1="select * from donor where blood_group='$bg' and gender='M'";
						$result1=mysqli_query($con,$query1);
						if($result1)
							echo 'The no of male donors with given blood group are : '.$result1->num_rows.',<br><br>';
						else
							echo "0,"; 
							
						
						
						$query2="select * from donor where blood_group='$bg' and gender='F'";
						$result2=mysqli_query($con,$query2);
						if($result2)
							echo 'The no of female donors with given blood group are : '.$result2->num_rows;
						else
							echo "0,"; 
		
                            mysqli_close($con); 
            }
                
    
                ?>
</center>
</body>
</html>
