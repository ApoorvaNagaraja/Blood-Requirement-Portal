<?php
session_start();
if(!isset($_SESSION['email'])){
header("location:login.php");
exit;
}

?>
<!--!DOCTYPE html-->
<html lang="en">
<head>
	<link id="page_favicon" href="images/favicon.ico" rel="icon" type="image/x-icon">
	<title>Blood Bank Management</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="css/style2.css">
	<link rel="stylesheet" href="css/my_reset.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/my_style.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/my_grid.css" type="text/css" media="screen">
	<script src="js/jquery-1.6.3.min.js" type="text/javascript"></script>
	<script src="js/tabs.js" type="text/javascript"></script>
	</head>
<body id="page1">
<div class="bg">

<header>
    
	
<?php
   			 
$hostname="localhost";
$username="root";
$password="root";
$database="bloodbank";
$con=mysqli_connect($hostname,$username,$password,$database);
            	?>
 
	
	
 <div class="main">
      <div class="wrapper p3">
        <h1><a href="login.php">Blood Bank</a></h1>
        
      </div>
    </div>
	</header>
	
	<form action = "" method = "post">
                                <div class="form-group">
                                	<div class="input-group">
									 <input class = "form-control" placeholder="Donor id" type="text" name="donorid" aria-describedby="name-format" required aria-required=”true”   />
<br>
 <input class = "form-control" type="text" name="name" placeholder="Donor name" aria-describedby="name-format" required aria-required=”true” pattern="[.A-Za-z ]*" />
	<br>								 
   									 <input class = "form-control" placeholder="Mobile number" type="text" maxlength="10" name="ph_number" required aria-describedby="name-format" required aria-required=”true” pattern="[789][0-9]{9}" />
		<br>							 
									 <input class = "form-control" placeholder="e-mail" type="email" name="email_id" required  />
			<br>						 
									 <input class = "form-control" type="date" placeholder="DOB" name="dob" required />
				<br>					 
									<!-- <input class = "form-control" type="text" placeholder="Gender" maxlength="1" name="gender" aria-describedby="name-format" required aria-required=”true” pattern="[m||M]||[f||F]" />
					<br>--> 
									<input class = "form-control" type="text" maxlength="3" placeholder="Age" name="age" required aria-describedby="name-format" required aria-required=”true” pattern="[0-9]*"  />
						<br>
				<label>Gender
						<select class="border" name="gender" >
							
							<option value="M">M</option>
							<option value="F">F</option>						
						</select>
                </label>
				<br>
							 
									<label>Blood Group
                    <select class="border" name="blood_group" >
							<!--<option >Blood Group</option>-->
							<option value="O+">O+</option>
							<option value="O-">O-</option>
							<option value="B+">B+</option>
							<option value="B-">B-</option>
							<option value="AB+">AB+</option>
							<option value="AB-">AB-</option>
							<option value="A+">A+</option>
							<option value="A-">A-</option>
				</select>
                </label>
				
								<br>	
<label>Area<select class="border" name="area">
							<option value="Bangalore North">Bangalore North</option>
							<option value="Bangalore South">Bangalore South</option>
							<option value="Bangalore East">Bangalore East</option>
							<option value="Bangalore West">Bangalore West</option>
				</select>
                </label>
<br>				
									<br>
									<button type="submit" class="btn btn-lg btn-danger">INSERT</button>
   						 									
   									<?php
   										 
   										 if(isset($_POST['donorid']) && isset($_POST['name'])){
   										 //echo "hey elseif";
										 //echo $_REQUEST['email_id'];
										 $query1=" INSERT INTO `donor`(`d_id`, `name`, `ph_number`, `email_id`, `dob`, `gender`, `age`, `blood_group`, `area`, `a_id`) VALUES ('{$_POST['donorid']}', '{$_POST['name']}','{$_POST['ph_number']}','{$_POST['email_id']}', '{$_POST['dob']}','{$_POST['gender']}','{$_POST['age']}','{$_POST['blood_group']}','{$_POST['area']}','{$_POST['a_id']}') ";
   										 
										
										 
   										 $result1=mysqli_query($con,$query1);
										 if($result1)
										 {
										 echo "Entry successfully Inserted";
										 //var_dump($con);
										 // $result2=mysqli_query($con,$query2);
   										 }   								 
   										}
   										 ?>   									


									</div>
									 </div>
									 </form>
									 <br>
							<form action="s_index.php" method="post">
   						 <button type="submit" class="btn btn-lg btn-danger">BACK</button>	 
                         	</form>

									 </body>
</html>									 