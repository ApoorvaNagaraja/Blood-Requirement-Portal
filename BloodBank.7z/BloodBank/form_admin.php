
<html lang="en">
<head>
   <link id="page_favicon" href="images/favicon.ico" rel="icon" type="image/x-icon">
    <title>SIGN UP FORM</title>
</head>
<style type="text/css">
      
    #wrapper {
        width:450px;
        margin:0 auto;
        font-family:Verdana, sans-serif;
    }
    legend {
        color:#0481b1;
        font-size:16px;
        padding:0 10px;
        background:#fff;
        -moz-border-radius:4px;
        box-shadow: 0 1px 5px rgba(4, 129, 177, 0.5);
        padding:5px 10px;
        text-transform:uppercase;
        font-family:Helvetica, sans-serif;
        font-weight:bold;
    }
    fieldset {
        border-radius:7px;
        background: #fff; 
       /* background: -moz-linear-gradient(#fff, #f9fdff);
        background: -o-linear-gradient(#fff, #f9fdff);
		background: -webkit-gradient(linear, 0% 0%, 0% 100%, from(#fff), to(#f9fdff)); 
        background: -webkit-linear-gradient(#fff, #f9fdff);*/
        padding:30px;
        border-color:rgba(4, 129, 177, 0.4);
    }
    input,
    textarea {
        color: #373737;
        background: #fff;
        border: 1px solid #CCCCCC;
        color: #aaa;
        font-size: 14px;
        line-height: 0.8em;
        margin-bottom:15px;

        /*-moz-border-radius:4px;
        -webkit-border-radius:4px;*/
        border-radius:4px;
        box-shadow: 0 1px 2px rgba(0, 0, 0, 0.1) inset, 0 1px 0 rgba(255, 255, 255, 0.2);
    }
    input[type="text"],
    input[type="password"]{
        padding: 8px 6px;
        height: 22px;
        width:280px;
    }
    input[type="text"]:focus,
    input[type="password"]:focus {
        background:#f5fcfe;
        text-indent: 0;
        z-index: 1;
        color: #373737;
        -webkit-transition-duration: 400ms;
        -webkit-transition-property: width, background;
        -webkit-transition-timing-function: ease;
        -moz-transition-duration: 400ms;
        -moz-transition-property: width, background;
        -moz-transition-timing-function: ease;
        -o-transition-duration: 400ms;
        -o-transition-property: width, background;
        -o-transition-timing-function: ease;
        width: 380px;
        
        border-color:#ccc;
        box-shadow:0 0 5px rgba(4, 129, 177, 0.5);
        opacity:0.6;
    }
    input[type="submit"]{
        background: #222;
        border: none;
        text-shadow: 0 -1px 0 rgba(0,0,0,0.3);
        text-transform:uppercase;
        color: #eee;
        cursor: pointer;
        font-size: 15px;
        margin: 5px 0;
        padding: 5px 22px;
        -moz-border-radius: 4px;
        border-radius: 4px;
        -webkit-border-radius:4px;
        -webkit-box-shadow: 0px 1px 2px rgba(0,0,0,0.3);
        -moz-box-shadow: 0px 1px 2px rgba(0,0,0,0.3);
        box-shadow: 0px 1px 2px rgba(0,0,0,0.3);
    }
    textarea {
        padding:3px;
        width:96%;
        height:100px;
    }
    textarea:focus {
        background:#ebf8fd;
        text-indent: 0;
        z-index: 1;
        color: #373737;
        opacity:0.6;
        box-shadow:0 0 5px rgba(4, 129, 177, 0.5);
        border-color:#ccc;
    }
   .small {
        line-height:14px;
        font-size:12px;
        color:#999898;
        margin-bottom:3px;
    } 
	input:valid,
	input:in-range {
    background:hsl(120, 50%, 90%);
    border-color:hsl(120, 50%, 50%);
}

input:invalid,
input:out-of-range {
    border-color:hsl(0, 50%, 50%);
    background:hsl(0, 50%, 90%);
}
</style>
<body>
    <div id="wrapper">
        <form action="System_user.php" method="post" >
            <fieldset>
                <legend>Registration Page</legend>
                <div>
				<input type="text" name="s_id" id="ID" placeholder="ID" required aria-describedby="name-format" required aria-required=”true” pattern="[A-Za-z0-9]+"/>
				</div>
                <div>
				<input type="text" name="institution" placeholder="Institution" id="institution" aria-describedby="name-format" required aria-required=”true” pattern="[A-Za-z]+||[A-Za-z]+\s[A-Za-z]+"/>
				
                </div>
				<div>
				<input id="name" name="name" value=""  placeholder="Name" aria-describedby="name-format" required aria-required=”true” pattern="[A-Za-z]+||[A-Za-z]+\s[A-Za-z]+">
				
				 <div>
				 
				 <input type="text" name="ph_number" placeholder="Phone Number" id="phone_number" required aria-describedby="name-format" required aria-required=”true” pattern="[789][0-9]{9}"/>
				 </div>
				 <div>
                    <input type="email" name="email" id="email" placeholder="E-mail" required>
                
                	</div>
                    <input type="password" name="password_s" placeholder="Password" id="pwd" required/>
                </div>
				<div>
				 <input type="text"  placeholder="Code" id="code" required aria-describedby="name-format" required aria-required=”true” pattern="su_rvce_21212"/>
                
				</div>
				<input type="submit" value="SEND">
				</div>
            </fieldset>    
        </form>
    </div>
	
</body>
</html>


